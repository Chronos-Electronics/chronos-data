This directory is for adding YUNG's Law configurations specific to certain dimensions.
For more information, please see the wiki:
https://github.com/yungnickyoung/YUNGs-Law/wiki